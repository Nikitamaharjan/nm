<?php include_once "./include/header.php"; ?>

<div class="container">
    <div class="row">
        <img src="images.png" class="col-4 card-img-top" alt="Logo">

        <div class="container col-8" style="margin-top: 50px;">
            <div class="card">
               
            

                <div class="card-body">

                <strong class="card-title"></strong>
                <ul>
                    <li>Handy Man On Service is the leading platform for connecting individuals looking for household services with top-quality, pre-screened independent service professionals. From home cleaning to handyman services, Handy instantly matches thousands of customers every week with top-rated professionals in cities all around the world. With a seamless 60-second booking process, secure payment, and backed by the Handy Happiness Guarantee, Handy is the easiest, most convenient way to book home services.</li>
                    
                </ul>
            </div>

            <div class="card-footer text-center">
                Thank you to the many people who've subsequently joined the team and invested in Handy Man On Service. It's because of your help that we're well on our way to changing the way the world buys services.
            </div>
            </div>
        </div>
    </div>
</div>


<?php include_once "./include/footer.php"; ?>
